#ifndef EMPLEADO_H
#define EMPLEADO_H

#include "persona.h"
#include <string>

namespace Salud {

    class Empleado : public Persona {
    private:
        std::string cargo;
        double valorHora;
        int horasTrabajadas;
        std::string departamento;

    public:
        Empleado(const std::string& nombre, int edad, double estatura, double peso,
                 const std::string& cargo, double valorHora, int horasTrabajadas, const std::string& departamento);

        void setCargo(const std::string& cargo);
        std::string getCargo() const;

        void setValorHora(double valorHora);
        double getValorHora() const;

        void setHorasTrabajadas(int horasTrabajadas);
        int getHorasTrabajadas() const;

        void setDepartamento(const std::string& departamento);
        std::string getDepartamento() const;

        double calcularHonorarios() const;
    };

}

#endif