#ifndef PERSONA_H
#define PERSONA_H

#include <string>

namespace Salud {
    class Persona {
    protected:
        std::string nombre;
        std::string apellido;
        std::string tipoDocumento;
        char sexo;
        int numeroDocumento;
        int edad;
        double estatura;
        double peso;

    public:
        Persona(const std::string& nombre, int edad, double estatura, double peso);

        void setNombre(const std::string& nombre);
        std::string getNombre() const;

        void setApellido(const std::string& apellido);
        std::string getApellido() const;

        void setTipoDocumento(const std::string& tipoDocumento);
        std::string getTipoDocumento() const;

        void setNumeroDocumento(int numeroDocumento);
        int getNumeroDocumento() const;

        void setSexo(char sexo);
        char getSexo() const;

        void setEdad(int edad);
        int getEdad() const;

        void setEstatura(double estatura);
        double getEstatura() const;

        void setPeso(double peso);
        double getPeso() const;

        std::string calcularIMC() const;
    };
}

#endif