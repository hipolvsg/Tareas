#include "persona.h"
#include <iostream>
#include <cmath>
#include <stdexcept>

using namespace std;

namespace Salud {

    Persona::Persona(const string& nombre, int edad, double estatura, double peso)
        : nombre(nombre), edad(edad), estatura(estatura), peso(peso) {}

    void Persona::setNombre(const string& nombre) { 
        this->nombre = nombre; 
    }

    string Persona::getNombre() const {
        return nombre;
    }
    void Persona::setEdad(int edad) {
        if (edad < 0) {
            this->edad = edad * -1;
        } else if (edad == 0) {
            throw invalid_argument("La edad debe ser mayor que cero.");
        } else {
            this->edad = edad;
        }
    }

    int Persona::getEdad() const {
        return edad;
    }

    void Persona::setPeso(double peso) {
        if (peso < 0) {
            this->peso = peso * -1;
        } else if (peso == 0) {
            throw invalid_argument("El peso debe ser mayor que cero.");
        } else {
            this->peso = peso;
        }
    }

    double Persona::getPeso() const {
        return peso;
    }

    void Persona::setEstatura(double estatura) {
        if (estatura < 0) {
            this->estatura = estatura * -1;
        } else if (estatura == 0) {
            throw invalid_argument("La estatura debe ser mayor que cero.");
        } else {
            this->estatura = estatura;
        }
    }

    double Persona::getEstatura() const {
        return estatura;
    }

    string Persona::calcularIMC() const {
        if (estatura < 0) {
            double nuevaEstatura = estatura * -1;
            double imc = peso / (nuevaEstatura * nuevaEstatura);
            if (imc < 20) {
                return "PESOBAJO";
            } else if (imc >= 20 && imc <= 25) {
                return "PESOIDEAL";
            } else {
                return "SOBREPESO";
            }
        }else if (estatura == 0) {
            throw invalid_argument("La estatura debe ser mayor que cero.");
        }
        double imc = peso / (estatura * estatura);
        if (imc < 20) {
            return "PESOBAJO";
        } else if (imc >= 20 && imc <= 25) {
            return "PESOIDEAL";
        } else {
            return "SOBREPESO";
        }
    }
    void Persona::setApellido(const string& apellido) {
        this->apellido = apellido;
    }
    string Persona::getApellido() const {
        return apellido;
    }
    void Persona::setTipoDocumento(const string& tipoDocumento) {
        this->tipoDocumento = tipoDocumento;
    }
    void Persona::setSexo(char sexo) {
        this->sexo = sexo;
    }
    char Persona::getSexo() const {
        return sexo;
    }
    string Persona::getTipoDocumento() const {
        return tipoDocumento;
    }
    void Persona::setNumeroDocumento(int numeroDocumento) {
        this->numeroDocumento = numeroDocumento;
    }
    int Persona::getNumeroDocumento() const {
        return numeroDocumento;
    }
}