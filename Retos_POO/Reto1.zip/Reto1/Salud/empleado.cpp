#include "empleado.h"

namespace Salud {

    Empleado::Empleado(const std::string& nombre, int edad, double estatura, double peso,
                       const std::string& cargo, double valorHora, int horasTrabajadas, const std::string& departamento)
        : Persona(nombre, edad, estatura, peso),
          cargo(cargo), valorHora(valorHora), horasTrabajadas(horasTrabajadas), departamento(departamento) {}

    void Empleado::setCargo(const std::string& cargo) {
        this->cargo = cargo;
    }

    std::string Empleado::getCargo() const {
        return cargo;
    }

    void Empleado::setValorHora(double valorHora) {
        this->valorHora = valorHora;
    }

    double Empleado::getValorHora() const {
        return valorHora;
    }

    void Empleado::setHorasTrabajadas(int horasTrabajadas) {
        this->horasTrabajadas = horasTrabajadas;
    }

    int Empleado::getHorasTrabajadas() const {
        return horasTrabajadas;
    }

    void Empleado::setDepartamento(const std::string& departamento) {
        this->departamento = departamento;
    }

    std::string Empleado::getDepartamento() const {
        return departamento;
    }

    double Empleado::calcularHonorarios() const {
        double valorTotal = valorHora * horasTrabajadas;
        double reteica = valorTotal * 0.00966;
        return valorTotal - reteica;
    }

}