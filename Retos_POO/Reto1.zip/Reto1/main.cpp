#include "Principal/inicio.h"
#include <iostream>
#include <cmath>
#include <stdexcept>

using namespace std;

int main(){
    cout << "Gracias por preferirnos :D ." << endl;

    Principal::Inicio::ejecutar();

    return 0;
}