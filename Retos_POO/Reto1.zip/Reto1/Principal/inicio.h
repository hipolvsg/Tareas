#ifndef INICIO_H
#define INICIO_H

#include "../Salud/persona.h"

namespace Principal {

    class Inicio {
    public:
        static void ejecutar();
    };

}

#endif