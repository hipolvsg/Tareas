#include "Inicio.h"
#include "../Salud/empleado.h"
#include <iostream>
#include <string>
#include <stdexcept>

using namespace std;

namespace Principal {

    void Inicio::ejecutar() {
        cout << "\t\033[1;36mREGISTRO DE SALUD Y EMPLEADO\033[0m\n\n";

        string nombre, apellido, tipoDocumento, cargo, departamento;
        char sexo;
        int numeroDocumento, edad, horasTrabajadas;
        double estatura, peso, valorHora;

        // Lectura de datos basicos de Persona
        cout << "\tNombre: ";
        cin >> nombre;
        cout << "\tApellido: ";
        cin >> apellido;
        cout << "\tTipo de documento: ";
        cin >> tipoDocumento;
        cout << "\tNumero de documento: ";
        cin >> numeroDocumento;
        cout << "\tSexo (M/F): ";
        cin >> sexo;
        cout << "\tEdad: ";
        cin >> edad;
        cout << "\tEstatura (m): ";
        cin >> estatura;
        cout << "\tPeso (kg): ";
        cin >> peso;

        // Lectura de datos especificos de Empleado (Reto 3)
        cout << "\tCargo: ";
        cin >> cargo;
        cout << "\tDepartamento: ";
        cin >> departamento;
        cout << "\tValor por hora: ";
        cin >> valorHora;
        cout << "\tHoras trabajadas: ";
        cin >> horasTrabajadas;

        try {
            // Instancia de la subclase Empleado
            Salud::Empleado empleado1(nombre, edad, estatura, peso, cargo, valorHora, horasTrabajadas, departamento);

            empleado1.setApellido(apellido);
            empleado1.setTipoDocumento(tipoDocumento);
            empleado1.setNumeroDocumento(numeroDocumento);
            empleado1.setSexo(sexo);

            // Seccion Reto 1 y Reto 2: Datos personales e IMC
            cout << "\n\t\033[1;32mRESULTADOS PERSONA\033[0m\n";
            cout << "\t\033[1mNOMBRE: \033[0m" << empleado1.getNombre() << " " << empleado1.getApellido() << "\n";
            cout << "\t\033[1mDOCUMENTO: \033[0m" << empleado1.getTipoDocumento() << " " << empleado1.getNumeroDocumento() << "\n";
            cout << "\t\033[1mSEXO: \033[0m" << empleado1.getSexo() << "\n";
            cout << "\t\033[1mEDAD: \033[0m" << empleado1.getEdad() << "\n";
            cout << "\t\033[1mESTATURA: \033[0m" << empleado1.getEstatura() << " m\n";
            cout << "\t\033[1mPESO: \033[0m" << empleado1.getPeso() << " kg\n";

            string resultadoIMC = empleado1.calcularIMC();

            if (resultadoIMC == "PESOBAJO") {
                cout << "\t\033[1;33mRESULTADO IMC: \033[0m" << resultadoIMC << " (Bajo peso)\n";
            } else if (resultadoIMC == "PESOIDEAL") {
                cout << "\t\033[1;33mRESULTADO IMC: \033[0m" << resultadoIMC << " (Peso ideal)\n";
            } else if (resultadoIMC == "SOBREPESO") {
                cout << "\t\033[1;33mRESULTADO IMC: \033[0m" << resultadoIMC << " (Sobrepeso)\n";
            }

            // Seccion Reto 3: Datos laborales y Honorarios
            cout << "\n\t\033[1;32mDETALLE DE LIQUIDACION EMPLEADO\033[0m\n";
            cout << "\t\033[1mCARGO: \033[0m" << empleado1.getCargo() << "\n";
            cout << "\t\033[1mDEPARTAMENTO: \033[0m" << empleado1.getDepartamento() << "\n";
            cout << "\t\033[1mHORAS TRABAJADAS: \033[0m" << empleado1.getHorasTrabajadas() << "\n";
            cout << "\t\033[1mVALOR POR HORA: \033[0m$" << empleado1.getValorHora() << "\n";
            cout << "\t\033[1mTOTAL A PAGAR (NETO CON RETEICA): \033[0m$" << empleado1.calcularHonorarios() << "\n";

        } catch (const invalid_argument& e) {
            cout << "\n\t\033[1;31mERROR: " << e.what() << "\033[0m\n";
        }
    }

}